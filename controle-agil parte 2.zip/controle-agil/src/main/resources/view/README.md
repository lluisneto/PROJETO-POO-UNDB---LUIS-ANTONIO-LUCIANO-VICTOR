# 🖼️ view

Aqui ficam os arquivos **`.fxml`**, que descrevem o visual das telas JavaFX (botões, campos, tabelas). O FXML é parecido com HTML: descreve a tela, e a lógica fica no `controller`.

## Telas previstas

| Arquivo | Tela |
|---------|------|
| `principal.fxml` | Tela inicial / menu |
| `clientes.fxml` | Cadastro de clientes |
| `pedidos.fxml` | Registro de pedidos e agenda do dia |
| `fiado.fxml` | Conta fiado e relatório de devedores |
