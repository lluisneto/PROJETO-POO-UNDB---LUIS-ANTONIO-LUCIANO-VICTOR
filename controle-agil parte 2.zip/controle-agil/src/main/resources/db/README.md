# 🛢️ db

Aqui fica o **`schema.sql`**: o script que cria as tabelas do banco SQLite quando o sistema roda pela primeira vez.

## Tabelas previstas

| Tabela | Guarda |
|--------|--------|
| `cliente` | Dados dos clientes e limite de crédito |
| `produto` | Salgados e preços |
| `pedido` | Pedidos, data/hora de entrega e status |
| `item_pedido` | Itens de cada pedido |
| `movimentacao_fiado` | Compras fiado e pagamentos de cada cliente |

> O arquivo do banco (`.db`) **não vai para o GitHub**: está no `.gitignore`. Cada integrante gera o seu rodando o sistema.
