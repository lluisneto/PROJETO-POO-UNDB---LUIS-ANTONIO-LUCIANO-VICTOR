# ⚙️ service

Aqui ficam as **regras de negócio**: as validações e decisões do sistema.

## Classes previstas

| Classe | Regras que aplica |
|--------|-------------------|
| `PedidoService` | Pedido precisa de data/hora e de pelo menos um item; controla as mudanças de status |
| `FiadoService` | Respeita o limite de crédito; não aceita pagamento maior que o saldo |

## Regra da pasta

O `service` fica no meio do caminho: recebe o pedido da tela (`controller`), aplica as regras e usa o `repository` para salvar. As regras de negócio estão descritas em [`docs/requisitos/requisitos.md`](../../../../../../../docs/requisitos/requisitos.md).
