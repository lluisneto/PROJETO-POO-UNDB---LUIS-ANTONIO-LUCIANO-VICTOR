# 🗄️ repository

Aqui ficam as classes que **conversam com o banco de dados** (SQLite): salvar, buscar, atualizar e excluir.

## Classes previstas

| Classe | Responsável por |
|--------|-----------------|
| `ClienteRepository` | Salvar e buscar clientes |
| `ProdutoRepository` | Salvar e buscar produtos |
| `PedidoRepository` | Salvar pedidos e buscar a agenda do dia |
| `ContaFiadoRepository` | Salvar movimentações e buscar saldos |

## Regra da pasta

Só tem SQL e acesso a dados aqui, **nenhuma regra de negócio**. Ex.: o repository salva o pagamento, mas quem verifica se o valor é maior que o saldo é o `service`.
