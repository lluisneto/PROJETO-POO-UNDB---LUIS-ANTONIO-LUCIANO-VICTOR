# 📦 model

Aqui ficam as **classes do domínio**: as "coisas" do negócio do cliente, com seus dados e comportamentos.

## Classes previstas

| Classe | O que representa |
|--------|------------------|
| `Pessoa` | Classe abstrata com nome e telefone |
| `Cliente` | Cliente da distribuidora (herda de `Pessoa`) |
| `Produto` | Salgado vendido |
| `Pedido` | Pedido com itens, data/hora de entrega e status |
| `ItemPedido` | Um produto dentro do pedido, com quantidade |
| `StatusPedido` | Enum com os estados do pedido |
| `ContaFiado` | Saldo devedor e limite de crédito do cliente |
| `Pagamento` e subclasses | Formas de pagamento (dinheiro, Pix, fiado) |

## Regra da pasta

As classes daqui **não acessam banco de dados nem telas**. Elas só sabem sobre si mesmas. Ex.: `Pedido` sabe calcular o próprio total, mas não sabe se salvar.
