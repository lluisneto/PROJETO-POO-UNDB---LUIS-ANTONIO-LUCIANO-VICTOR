# 🎮 controller

Aqui ficam as classes que **controlam as telas** JavaFX: elas reagem aos cliques do usuário e mostram os dados.

## Classes previstas

| Classe | Tela |
|--------|------|
| `PrincipalController` | Tela inicial / menu |
| `ClienteController` | Cadastro de clientes |
| `PedidoController` | Registro de pedidos e agenda do dia |
| `FiadoController` | Conta fiado e relatório de devedores |

## Regra da pasta

O `controller` **não acessa o banco diretamente**. Ele pega o que o usuário digitou, chama o `service` e mostra o resultado na tela. O visual das telas fica em `src/main/resources/view/`.
