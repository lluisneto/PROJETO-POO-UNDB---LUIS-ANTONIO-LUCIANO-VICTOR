# 🧪 Testes

Aqui ficam os **testes automatizados** com JUnit 5: código que testa o código, pra garantir que as regras funcionam e continuam funcionando depois de cada mudança.

## Testes previstos

| Classe de teste | O que verifica |
|-----------------|----------------|
| `PedidoTest` | Cálculo do total do pedido |
| `ContaFiadoTest` | Compra respeita o limite; pagamento reduz o saldo; pagamento não passa do saldo |
| `PedidoServiceTest` | Pedido sem itens ou sem data/hora é recusado |

## Regra da pasta

A estrutura de pacotes aqui **espelha** a de `src/main/java`. Ex.: o teste de `model/ContaFiado.java` fica em `model/ContaFiadoTest.java`.
