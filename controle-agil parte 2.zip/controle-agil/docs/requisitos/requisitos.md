# 📋 Levantamento de Requisitos: Controle Ágil

> **Status:** versão inicial (rascunho). Os itens marcados com 🔎 precisam ser validados com o cliente.

## 1. Contexto

| Campo | Informação |
|-------|------------|
| **Cliente** | A L Salgados Distribuidora |
| **CNPJ** | 65.738.200/0001-91 |
| **Ramo** | Distribuição de salgados |

## 2. Problemas relatados pelo cliente

1. **Pedidos não agendados:** os pedidos chegam pelo WhatsApp e, por causa do volume de mensagens, às vezes não são agendados e o horário é perdido.
2. **Fiado no caderno:** as vendas fiado são anotadas manualmente em um caderno.
3. **Falta de entregadores:** a equipe de entrega não dá conta da demanda.

## 3. Escopo desta etapa (MVP)

Nesta primeira etapa o sistema resolve os problemas **1** e **2**. O problema **3** (entregas) fica para a etapa 2.

## 4. Requisitos funcionais (RF)

*O que o sistema deve **fazer**.*

### Clientes e produtos
| ID | Requisito |
|----|-----------|
| RF01 | Cadastrar, editar e listar clientes (nome, telefone, endereço) |
| RF02 | Cadastrar, editar e listar produtos (nome e preço) |

### Pedidos
| ID | Requisito |
|----|-----------|
| RF03 | Registrar pedido com cliente, itens, quantidades, **data e horário de entrega** |
| RF04 | Calcular automaticamente o valor total do pedido |
| RF05 | Alterar o status do pedido: Pendente, Em produção, Saiu para entrega, Entregue, Cancelado |
| RF06 | Exibir a agenda do dia, com os pedidos ordenados por horário |
| RF07 | Destacar pedidos com entrega próxima 🔎 *(definir com quanto tempo de antecedência)* |

### Fiado
| ID | Requisito |
|----|-----------|
| RF08 | Registrar compra fiado, lançando o valor na conta do cliente |
| RF09 | Registrar pagamento (total ou parcial) |
| RF10 | Calcular e exibir o saldo devedor de cada cliente |
| RF11 | Definir um limite de crédito por cliente |
| RF12 | Gerar relatório de devedores (quem deve, quanto e desde quando) |
| RF13 | Exibir o histórico de compras e pagamentos de cada cliente |

## 5. Requisitos não funcionais (RNF)

***Como** o sistema deve funcionar (qualidade, tecnologia, restrições).*

| ID | Requisito |
|----|-----------|
| RNF01 | Aplicação desktop desenvolvida em Java com JavaFX |
| RNF02 | Dados salvos localmente em banco SQLite, sem precisar de internet |
| RNF03 | Interface simples, usável por quem não tem experiência com sistemas |
| RNF04 | Código organizado em camadas (model, repository, service, controller) |
| RNF05 | Regras de negócio principais cobertas por testes automatizados (JUnit) |

## 6. Regras de negócio (RN)

*Regras do negócio do cliente que o sistema precisa respeitar.*

| ID | Regra |
|----|-------|
| RN01 | Todo pedido precisa ter data e horário de entrega |
| RN02 | Um pedido precisa ter pelo menos um item |
| RN03 | Uma compra fiado não pode ultrapassar o limite de crédito do cliente 🔎 *(bloquear ou só avisar?)* |
| RN04 | Um pagamento não pode ser maior que o saldo devedor |
| RN05 | Pedido entregue ou cancelado não pode mais mudar de status |

## 7. Perguntas pendentes para o cliente 🔎

- Quantos pedidos, em média, vocês recebem por dia?
- Hoje existe limite de fiado por cliente? Qual o prazo para pagar?
- Quem vai usar o sistema no dia a dia?
- Qual computador será usado (Windows, Linux...)?
- Com quanto tempo de antecedência querem ser avisados de um pedido?
- Quantos entregadores vocês têm hoje? *(para a etapa 2)*
