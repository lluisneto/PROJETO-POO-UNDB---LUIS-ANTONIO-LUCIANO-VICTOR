# 📐 Diagramas

Esta pasta guarda os diagramas UML do projeto.

## Diagramas planejados

- [x] Diagrama de classes (rascunho abaixo)
- [ ] Diagrama de casos de uso
- [ ] Diagrama de sequência do fluxo "registrar pedido"

## Diagrama de classes: rascunho v1

> Rascunho inicial; ainda vai mudar conforme o projeto evolui. O GitHub desenha este diagrama automaticamente a partir do código Mermaid abaixo.

```mermaid
classDiagram
    class Pessoa {
        <<abstract>>
        -String nome
        -String telefone
    }
    class Cliente {
        -String endereco
        -ContaFiado contaFiado
    }
    class Produto {
        -String nome
        -BigDecimal preco
    }
    class Pedido {
        -Cliente cliente
        -List~ItemPedido~ itens
        -LocalDateTime dataHoraEntrega
        -StatusPedido status
        +calcularTotal() BigDecimal
        +alterarStatus(StatusPedido novoStatus)
    }
    class ItemPedido {
        -Produto produto
        -int quantidade
        +calcularSubtotal() BigDecimal
    }
    class StatusPedido {
        <<enumeration>>
        PENDENTE
        EM_PRODUCAO
        SAIU_PARA_ENTREGA
        ENTREGUE
        CANCELADO
    }
    class ContaFiado {
        -BigDecimal saldoDevedor
        -BigDecimal limiteCredito
        +registrarCompra(BigDecimal valor)
        +registrarPagamento(BigDecimal valor)
        +getSaldoDevedor() BigDecimal
    }
    class Pagamento {
        <<abstract>>
        -BigDecimal valor
        +processar()*
    }
    class PagamentoDinheiro
    class PagamentoPix
    class PagamentoFiado

    Pessoa <|-- Cliente
    Cliente "1" --> "1" ContaFiado
    Pedido "*" --> "1" Cliente
    Pedido "1" *-- "1..*" ItemPedido
    ItemPedido "*" --> "1" Produto
    Pedido --> StatusPedido
    Pedido "1" --> "*" Pagamento
    Pagamento <|-- PagamentoDinheiro
    Pagamento <|-- PagamentoPix
    Pagamento <|-- PagamentoFiado
```

## Como ler o diagrama

| Símbolo | Significado |
|---------|-------------|
| `-` | Atributo privado (encapsulamento) |
| `+` | Método público |
| `<<abstract>>` | Classe abstrata: não dá para criar objeto dela diretamente |
| `*` no fim do método | Método abstrato: cada subclasse implementa o seu |
| `<\|--` | Herança ("é um"): `Cliente` é uma `Pessoa` |
| `*--` | Composição: o `ItemPedido` só existe dentro de um `Pedido` |
| `-->` | Associação: uma classe conhece a outra |

**Por que `BigDecimal` e não `double` para dinheiro?** O `double` tem erros de arredondamento (em Java, `0.1 + 0.2` dá `0.30000000000000004`). Em valores de dinheiro isso vira centavo sumindo, então o padrão é usar `BigDecimal`.
